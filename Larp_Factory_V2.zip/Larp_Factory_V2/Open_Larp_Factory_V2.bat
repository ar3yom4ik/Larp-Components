@echo off
start "" "%~dp0Larp_Factory_V2.html"
