#!/bin/sh
cd "$(dirname "$0")" || exit 1
open "./Larp_Factory_V2.html"
