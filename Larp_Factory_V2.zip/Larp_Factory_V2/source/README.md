# Larp Factory Simulator V2 — source

Independent React, Vite, React Three Fiber and Three.js factory-layout simulator. The release number is V2; the interface keeps the original Larp Components 5.1 name. See `../README_V2.md` for the user guide and `../AI_DEVELOPER_HANDOFF.md` for architecture, formats, animation, tests, licensing and limitations.

```sh
# Node 20.19+ or 22.12+
npm ci
npm run dev -- --host 127.0.0.1 --port 4173 --strictPort
npx tsc --noEmit
npm run build
```

The complete `npm run build` runs Vite **and** post-build packing and produces the offline `dist/index.html`. Do not omit `scripts/embed-assets.mjs`. Run `npx playwright install chromium` for browser tests and see the handoff for commands. `THIRD_PARTY_LICENSES/` contains dependency and asset notices. The built-in rigged worker is Quaternius CC0 with Mixamo-style bone names; Adobe assets and credentials are not included.

The app is not affiliated with Visual Components or a certified industrial, safety or robot-control product. Imported meshes are visual only. Open executable project code only if trusted.
