#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v xdg-open >/dev/null 2>&1; then xdg-open "./Larp_Factory_V2.html"; elif command -v gio >/dev/null 2>&1; then gio open "./Larp_Factory_V2.html"; else echo "Open Larp_Factory_V2.html in a WebGL-capable browser." >&2; exit 1; fi
